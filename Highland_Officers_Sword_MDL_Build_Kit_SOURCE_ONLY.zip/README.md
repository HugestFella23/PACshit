# Highland Officer's Sword — actual Source MDL compile kit

**IMPORTANT: This is a build kit, NOT a compiled `.mdl`.** The bundled Source `.smd` and `.qc` files must be processed by **StudioMDL** or **StudioMDL-CE** before PAC3 can load a ZIP. A valid `.mdl` must be accompanied by `.vvd`, `.dx90.vtx`, and optional other model files. Do not give this source kit's ZIP URL to PAC3.

## Three models this kit compiles

- `highland_sword_held.mdl`: **recommended** for a hand-attached PAC3 sword. Sword alone, transformed to long-axis +Z with grip close to origin.
- `highland_officers_sword.mdl`: sword **plus** scabbard and both rings, preserving original arrangement.
- `highland_scabbard.mdl`: scabbard and rings, for a second PAC3 Model part worn on the hip.

## Easiest compilation: GitHub Actions (Windows runner)

1. Upload the contents of **this extracted folder** into a GitHub repository. Make sure `.github/workflows/compile-pac3.yml`, `source/`, `materials/`, and `scripts/` are preserved.
2. Open the repository's **Actions** tab → **Compile Highland Sword PAC3 MDL** → **Run workflow**.
3. If the build succeeds, download the **Highland-Sword-Compiled-PAC3-MDLs** build artifact and **extract it**. Inside are three separate `*_PAC3_MDL.zip` files.
4. Upload only the desired **inner ZIP** to GitHub or another direct-download host. Use its **raw URL**, not the GitHub `/blob/` page, in a PAC3 **Model** part.

NOTE: The GitHub Actions automation is provided as an untested convenience; it depends on StudioMDL-CE being downloadable and running successfully on GitHub's Windows runner. The `.qc`/`.smd` inputs are present, but no final `.mdl` has been independently compiled or game-tested here.

## Compile locally with StudioMDL-CE / Crowbar on Windows

1. Download StudioMDL-CE: https://github.com/DeadZoneLuna/StudioMDL-CE (the compiler is `bin/x64/cestudiomdl.exe` or `bin/cestudiomdl.exe`). Alternatively use the model compiler from your installed Garry's Mod in Crowbar.
2. Drag and drop `cestudiomdl.exe` onto `compile_with_studiomdl_ce.bat` to attempt all three compilations, or use Crowbar's Compile tab and choose one of the `source/*.qc` files.
3. The script requires Python 3 (`py -3`) to make the final ZIPs. Run `python scripts/make_pac3_zips.py` separately if compilation succeeded but the batch couldn't find Python.
4. Find each compiled ZIP in `PAC3_READY_OUTPUT/`. The packager verifies MDL `IDST` magic, the presence of `.vvd` and `.dx90.vtx`, and ZIP compression method 0 (Store).

## Materials and texture overrides in PAC3

**Source VMT paths** (the same path for each model, but only slots used by that geometry are exposed):

- `models/highland_officers_sword/sword`
- `models/highland_officers_sword/scabbard`
- `models/highland_officers_sword/scabbard_ring_1`
- `models/highland_officers_sword/scabbard_ring_2`

The `materials/` folder contains the Source `.VMT`/`.VTF` files; `textures/` contains the separately editable PNGs. All four submaterials initially sample the same UV atlas `sword_albedo.vtf` plus `sword_normal.vtf`. You can supply unique material overrides in PAC3. `.PNG` files are **not** included in the runtime PAC3 ZIP because its whitelist accepts model and Valve material files only.

If your PAC3 Model stays on 'downloading...', use a **Model** part, not the legacy model part. Remove any obsolete entry from the `garrysmod/data/pac3_cache` directory when retrying the **same URL** after a failed upload. Use a raw file link and ensure it is publicly accessible.

## Source license

Original Highland Officers Sword by Arnold Konrad, Sketchfab: https://sketchfab.com/3d-models/highland-officers-sword-f957820ce0c645f5a36d0e89350964ef
License: CC BY-NC 4.0: https://creativecommons.org/licenses/by-nc/4.0/
Attribution and noncommercial use conditions apply when distributing modified versions.
