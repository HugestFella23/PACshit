#!/usr/bin/env python3
"""Collect real, StudioMDL-compiled binaries into uncompressed PAC3 ZIPs."""
from pathlib import Path
from zipfile import ZipFile, ZIP_STORED
import sys

ROOT=Path(__file__).resolve().parents[1]
OUTPUT=ROOT/'PAC3_READY_OUTPUT'
MATERIALS=ROOT/'materials'
NAMES=('highland_officers_sword','highland_sword_held','highland_scabbard')
EXTENSIONS=('.mdl','.vvd','.dx90.vtx','.dx80.vtx','.sw.vtx','.phy','.vtx','.ani')

OUTPUT.mkdir(exist_ok=True)
compiled=list(ROOT.rglob('*.mdl'))
for name in NAMES:
    options=[p for p in compiled if p.stem==name and 'PAC3_READY_OUTPUT' not in p.parts]
    if not options:
        print(f'SKIP {name}: .mdl not compiled yet')
        continue
    model=options[0]
    if model.read_bytes()[:4]!=b'IDST':
        raise RuntimeError(f'{model}: not a compiled Valve MDL binary (missing IDST magic)')
    required=[model.with_suffix('.vvd'),model.parent/(name+'.dx90.vtx')]
    missing=[str(p) for p in required if not p.exists()]
    if missing:
        raise RuntimeError(f'{name}: StudioMDL output incomplete. Missing {missing}')
    out=OUTPUT/f'{name}_PAC3_MDL.zip'
    with ZipFile(out,'w',compression=ZIP_STORED,allowZip64=True) as z:
        for file in model.parent.iterdir():
            if file.is_file() and file.name.startswith(name+'.') and any(file.name.endswith(e) for e in EXTENSIONS):
                z.write(file,f'models/highland_officers_sword/{file.name}',compress_type=ZIP_STORED)
        for file in MATERIALS.rglob('*'):
            if file.is_file() and file.suffix.lower() in ('.vmt','.vtf'):
                z.write(file,file.relative_to(ROOT).as_posix(),compress_type=ZIP_STORED)
    with ZipFile(out) as z:
        assert all(i.compress_type==0 for i in z.infolist())
        assert any(i.filename.endswith('.mdl') for i in z.infolist())
    print(f'OK {out} ({out.stat().st_size/1024/1024:.1f} MiB)')
if not compiled:
    print('NO MDL FOUND. Compile the QC files in source/ with StudioMDL first.')
    sys.exit(2)
