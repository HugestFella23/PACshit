@echo off
setlocal
cd /d "%~dp0"
if "%~1"=="" (
  echo Drag and drop cestudiomdl.exe from StudioMDL-CE onto this BAT file.
  echo Or run: compile_with_studiomdl_ce.bat "C:\path\to\cestudiomdl.exe"
  pause
  exit /b 1
)
if not exist "%~1" (
  echo Compiler executable not found: "%~1"
  pause
  exit /b 2
)
for %%Q in (highland_officers_sword highland_sword_held highland_scabbard) do (
  echo.
  echo ==== Compiling %%Q ====
  "%~1" -nop4 "%~dp0source\%%Q.qc"
  if errorlevel 1 echo ERROR: %%Q compilation failed, see error text above.
)
py -3 "%~dp0scripts\make_pac3_zips.py"
if errorlevel 1 echo If Python is missing, install Python 3 or run the packager elsewhere.
echo.
echo PAC3 ZIPs (if compilation succeeded) are in PAC3_READY_OUTPUT
pause
