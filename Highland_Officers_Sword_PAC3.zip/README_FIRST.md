# Highland Officer's Sword — Garry's Mod PAC3 pack

**Contents:** UV-preserving Wavefront OBJ models, 1024x1024 PNG texture files,
OBJ material library (`.mtl`), and build sources for a real Source `.mdl`.

## Using it in PAC3 right now (OBJ route)

1. Extract `obj/highland_sword_only.obj` (or `obj/highland_sword_grip_pivot_upright.obj`
   for an upright sword with an approximate grip pivot).
2. Host the extracted `.obj` file at a publicly accessible **direct download URL**.
3. Host `textures/sword_albedo_1024.png` as a **separate direct URL**.
4. In PAC3 add a **Model** part. Set `model` to:

   `objhttps://YOUR_HOST/highland_sword_only.obj`

   If your PAC3 supports a legacy OBJ Model part, that is another option.
5. Add a **Material** child part and paste the PNG URL into **Base Texture**.
   Depending on PAC3 version, the Model part's own Material field can also work.
6. Adjust position/angles/size in PAC3 to attach it to the relevant bone.
   The geometry is exported in approximate Source units: 1 metre = 39.3701 units.

For sword **and** scabbard together choose `highland_sword_and_scabbard.obj`.
The combined OBJ has multiple named `usemtl` entries for editing software, but
PAC3 OBJ URL loading may ignore external `.mtl` files. Separate OBJ models
are provided for independent texture overrides:

- `highland_sword_only.obj` — sword in its original scene placement
- `highland_sword_grip_pivot_upright.obj` — sword with grip near pivot, long axis +Z
- `highland_scabbard_with_rings.obj` — scabbard including both rings
- `highland_scabbard_body.obj` — scabbard fabric/body by itself
- `highland_scabbard_ring_1.obj` and `_2.obj` — each ring independently
- `highland_sword_and_scabbard.obj` — full original arrangement

**Important ZIP limitation:** PAC3 loads a linked `.zip` as a Source
`.mdl` archive ONLY if it contains compiled `.mdl` + associated `.vvd` /
`.vtx` files. This ZIP is a distribution pack, **not** a ready-to-load PAC3
`.mdl` ZIP. Use the OBJ URL workflow above. The package also contains `.qc`
/ `.smd` build sources if you want to compile an `.mdl` on Windows later.

## Texture images

All parts share a SINGLE original UV atlas. Apply `sword_albedo_1024.png`
to each object; DO NOT expect one different colour map per part.
The normal, metallic, roughness, AO maps are separate optional images.
Metal/roughness/occlusion in glTF are packed into one image; extracted as:

- `sword_ao_1024.png` = red channel
- `sword_roughness_1024.png` = green channel
- `sword_metallic_1024.png` = blue channel

PAC3 documentation warns PNG files above 1024x1024 can display incorrectly;
these files have been resized to 1024x1024 for reliability.

## Source MDL material path / compiler route

The `source_mdl_build/model_source` folder contains a `.qc` and reference/idle
SMDs. Compile `highland_officers_sword.qc` with Crowbar + StudioMDL for GMod.
This sandbox does NOT contain StudioMDL, so **no compiled MDL is included**.

The `source_mdl_build/materials/models/highland_officers_sword` folder already
contains 1024px VTF files and four VMT files, using these material paths:

- `models/highland_officers_sword/sword`
- `models/highland_officers_sword/scabbard`
- `models/highland_officers_sword/scabbard_ring_1`
- `models/highland_officers_sword/scabbard_ring_2`

After compiling the `.mdl`, create a separate uncompressed ZIP containing ONLY
`models/` compiled `.mdl`, `.vvd`, `.dx90.vtx` (and other associated `.vtx`
files, if present) alongside `materials/` containing the VMT/VTF files.
Only THEN is it a directly loadable PAC3 `.mdl` ZIP, with these Source
submaterials exposed. Don't include the `.qc`, `.smd`, `.obj` or PNGs in this
runtime `.mdl` ZIP.

See `PAC3_MATERIAL_PATHS.txt` for the direct PAC3 settings and mappings.

## Source / attribution

Original asset: **Highland Officers Sword**
Creator: **Arnold Konrad** (Sketchfab user: akonrad)
Source: https://sketchfab.com/3d-models/highland-officers-sword-f957820ce0c645f5a36d0e89350964ef
License given in uploaded GLB metadata: **CC BY-NC 4.0**
https://creativecommons.org/licenses/by-nc/4.0/

This conversion should retain creator credit when you publish or share it;
non-commercial restrictions of the original license still apply.
